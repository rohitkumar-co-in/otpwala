


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."admin_dashboard_metrics"() RETURNS "jsonb"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT jsonb_build_object(
    'totalUsers', (SELECT count(*) FROM profiles),
    'totalOrders', (SELECT count(*) FROM orders),
    'ordersToday', (SELECT count(*) FROM orders WHERE (created_at AT TIME ZONE 'Asia/Kolkata')::date = (now() AT TIME ZONE 'Asia/Kolkata')::date),
    'activeOrders', (SELECT count(*) FROM orders WHERE status = 'waiting'),
    'otpDelivered', (SELECT count(*) FROM orders WHERE sms_code IS NOT NULL OR status IN ('code_received','completed')),
    'otpNotReceived', (SELECT count(*) FROM orders WHERE sms_code IS NULL AND status IN ('cancelled','expired','refunded')),
    'refundAmount', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type = 'refund' AND status = 'completed'),
    'refundCount', (SELECT count(*) FROM wallet_transactions WHERE type = 'refund' AND status = 'completed'),
    'refundsPending', (SELECT count(*) FROM orders WHERE refund_status IN ('pending','processing','failed')),
    'grossOtpSales', (SELECT coalesce(sum(sell_price_inr),0) FROM orders WHERE sms_code IS NOT NULL OR status IN ('code_received','completed')),
    'providerCostInr', (SELECT coalesce(sum(cost_price_inr),0) FROM orders WHERE sms_code IS NOT NULL OR status IN ('code_received','completed')),
    'grossProfit', (SELECT coalesce(sum(sell_price_inr - coalesce(cost_price_inr,0)),0) FROM orders WHERE sms_code IS NOT NULL OR status IN ('code_received','completed'))
  ) || public.wallet_funding_summary();
$$;


ALTER FUNCTION "public"."admin_dashboard_metrics"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."approve_payment_request_atomic"("p_request_id" "uuid", "p_admin_id" "text") RETURNS TABLE("transaction_id" "uuid", "balance_after" numeric)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_request public.payment_requests%ROWTYPE;
BEGIN
  SELECT * INTO v_request
  FROM public.payment_requests
  WHERE id = p_request_id
  FOR UPDATE;

  IF NOT FOUND THEN RAISE EXCEPTION 'payment_request_not_found'; END IF;
  IF v_request.status IN ('approved', 'paid') THEN RAISE EXCEPTION 'payment_request_already_approved'; END IF;
  IF v_request.status NOT IN ('pending', 'created') THEN RAISE EXCEPTION 'payment_request_not_pending'; END IF;

  IF COALESCE(v_request.amount, 0) <= 0 THEN RAISE EXCEPTION 'invalid_payment_amount'; END IF;

  UPDATE public.payment_requests
  SET status = 'approved',
      admin_notes = concat('Approved by ', p_admin_id),
      updated_at = now()
  WHERE id = p_request_id;

  RETURN QUERY SELECT * FROM public.post_wallet_transaction(
    v_request.user_id,
    v_request.amount,
    'topup',
    concat('Deposit approved (UTR: ', COALESCE(v_request.transaction_id, v_request.id::text), ')'),
    'payment_request',
    v_request.id::text,
    concat('topup:', v_request.id::text)
  );
END;
$$;


ALTER FUNCTION "public"."approve_payment_request_atomic"("p_request_id" "uuid", "p_admin_id" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."capture_order_event"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE event_name TEXT;
BEGIN
IF TG_OP='INSERT' THEN event_name:='created';
ELSIF NEW.sms_code IS NOT NULL AND OLD.sms_code IS DISTINCT FROM NEW.sms_code THEN event_name:='otp_received';
ELSIF NEW.refund_status='refunded' AND OLD.refund_status IS DISTINCT FROM NEW.refund_status THEN event_name:='refunded';
ELSIF OLD.status IS DISTINCT FROM NEW.status THEN event_name:='status_changed';
ELSE RETURN NEW; END IF;
INSERT INTO public.order_events(order_id,user_id,event_type,from_status,to_status,refund_status,details,created_at)
VALUES(NEW.id,NEW.user_id,event_name,CASE WHEN TG_OP='UPDATE' THEN OLD.status ELSE NULL END,NEW.status,NEW.refund_status,jsonb_strip_nulls(jsonb_build_object('service',NEW.service_name,'country',NEW.country_name)),COALESCE(NEW.updated_at,NEW.created_at,now()));
RETURN NEW; END; $$;


ALTER FUNCTION "public"."capture_order_event"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."check_email_exists"("p_email" "text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog', 'public', 'auth', 'extensions'
    AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM auth.users WHERE lower(email) = lower(trim(p_email))
    ) OR EXISTS (
        SELECT 1 FROM public.profiles WHERE lower(email) = lower(trim(p_email))
    );
END;
$$;


ALTER FUNCTION "public"."check_email_exists"("p_email" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_operational_records"() RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE recovered_count INTEGER := 0; intent_count INTEGER := 0; alert_count INTEGER := 0;
BEGIN
UPDATE public.purchase_intents SET status='failed', error_code='processing_timeout', error_message='Purchase processing timed out. Please start a new purchase.', updated_at=now() WHERE status='processing' AND updated_at < now() - interval '15 minutes';
GET DIAGNOSTICS recovered_count = ROW_COUNT;
DELETE FROM public.purchase_intents WHERE status IN ('completed','failed') AND updated_at < now() - interval '30 days';
GET DIAGNOSTICS intent_count = ROW_COUNT;
DELETE FROM public.operational_alerts WHERE created_at < now() - interval '90 days';
GET DIAGNOSTICS alert_count = ROW_COUNT;
RETURN jsonb_build_object('timed_out_intents',recovered_count,'deleted_intents',intent_count,'deleted_alerts',alert_count);
END; $$;


ALTER FUNCTION "public"."cleanup_operational_records"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."clear_user_history"("p_user_id" "uuid", "p_actor_id" "uuid", "p_mode" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  target public.profiles%ROWTYPE;
  actor_role TEXT;
  clear_id UUID := gen_random_uuid();
  clear_time TIMESTAMPTZ := clock_timestamp();
  orders_count INTEGER := 0;
  requests_count INTEGER := 0;
BEGIN
  IF p_mode IS NULL OR p_mode NOT IN ('all', 'preserve_funding') THEN
    RAISE EXCEPTION 'History clear mode must be all or preserve_funding';
  END IF;

  SELECT role INTO actor_role FROM public.profiles WHERE id = p_actor_id;
  IF actor_role IS DISTINCT FROM 'superadmin' THEN
    RAISE EXCEPTION 'Only a superadmin can clear user history';
  END IF;

  SELECT * INTO target FROM public.profiles WHERE id = p_user_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'User not found'; END IF;
  IF target.id = p_actor_id THEN RAISE EXCEPTION 'You cannot clear your own history'; END IF;
  IF target.role <> 'user' THEN RAISE EXCEPTION 'History can only be cleared for standard user accounts'; END IF;

  IF EXISTS (
    SELECT 1 FROM public.orders
    WHERE user_id = p_user_id AND status = 'waiting'
  ) THEN
    RAISE EXCEPTION 'This user has a waiting order. Resolve it before clearing history.';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM public.wallet_transactions w
    WHERE w.user_id = p_user_id
      AND w.type = 'deduction'
      AND w.reference_type = 'order'
      AND w.created_at >= now() - interval '5 minutes'
      AND NOT EXISTS (SELECT 1 FROM public.orders o WHERE o.id::text = w.reference_id)
  ) THEN
    RAISE EXCEPTION 'An order purchase is still being processed. Wait a few minutes before clearing history.';
  END IF;

  IF p_mode = 'all' AND EXISTS (
    SELECT 1 FROM public.payment_requests
    WHERE user_id = p_user_id AND status IN ('pending', 'created')
  ) THEN
    RAISE EXCEPTION 'This user has a pending deposit request. Resolve it before clearing all history.';
  END IF;

  SELECT count(*) INTO orders_count FROM public.orders WHERE user_id = p_user_id;
  SELECT count(*) INTO requests_count FROM public.payment_requests WHERE user_id = p_user_id;

  -- Full clear resets the spendable balance through the trusted ledger RPC.
  -- The debit stays in the protected audit trail but is hidden from the user's
  -- ordinary history feed by its dedicated reference type.
  IF p_mode = 'all' AND target.wallet_balance > 0 THEN
    PERFORM public.post_wallet_transaction(
      p_user_id,
      -target.wallet_balance,
      'deduction',
      'Wallet balance reset during admin history clear',
      'admin_history_clear',
      clear_id::text,
      'history-clear:' || clear_id::text
    );
  END IF;

  INSERT INTO public.admin_user_history_clears (
    id, user_id, cleared_at, mode, actor_id,
    wallet_balance_before, wallet_balance_after
  ) VALUES (
    clear_id, p_user_id, clear_time, p_mode, p_actor_id,
    target.wallet_balance,
    CASE WHEN p_mode = 'all' THEN 0 ELSE target.wallet_balance END
  );

  RETURN jsonb_build_object(
    'id', clear_id,
    'user_id', p_user_id,
    'mode', p_mode,
    'cleared_at', clear_time,
    'orders_hidden', orders_count,
    'payment_requests_hidden', CASE WHEN p_mode = 'all' THEN requests_count ELSE 0 END,
    'wallet_balance_before', target.wallet_balance,
    'wallet_balance_after', CASE WHEN p_mode = 'all' THEN 0 ELSE target.wallet_balance END
  );
END;
$$;


ALTER FUNCTION "public"."clear_user_history"("p_user_id" "uuid", "p_actor_id" "uuid", "p_mode" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."enforce_wallet_ledger_append_only"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF TG_OP <> 'INSERT' THEN
    RAISE EXCEPTION 'wallet_ledger_is_append_only';
  END IF;
  IF current_setting('app.wallet_posting', true) IS DISTINCT FROM 'trusted' THEN
    RAISE EXCEPTION 'wallet_ledger_must_use_post_wallet_transaction';
  END IF;
  IF NEW.balance_after IS NULL OR NEW.balance_after < 0 THEN
    RAISE EXCEPTION 'invalid_wallet_balance_after';
  END IF;
  IF NEW.type = 'opening_balance' THEN
    IF NEW.amount <> 0 OR NEW.reference_type <> 'financial_ledger_baseline' THEN
      RAISE EXCEPTION 'invalid_opening_balance_entry';
    END IF;
  ELSIF NEW.amount IS NULL OR NEW.amount <= 0 THEN
    RAISE EXCEPTION 'wallet_transaction_amount_must_be_positive';
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."enforce_wallet_ledger_append_only"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."erase_user_personal_data"("p_user_id" "uuid", "p_actor_id" "uuid", "p_request_id" "uuid" DEFAULT NULL::"uuid") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE p public.profiles%ROWTYPE; active_orders INTEGER; pending_payments INTEGER;
BEGIN
SELECT * INTO p FROM public.profiles WHERE id=p_user_id FOR UPDATE;
IF NOT FOUND THEN RAISE EXCEPTION 'User not found'; END IF;
IF p.role IN('admin','superadmin') THEN RAISE EXCEPTION 'Administrator accounts cannot be erased'; END IF;
IF NOT COALESCE(p.is_banned,false) THEN RAISE EXCEPTION 'User must be suspended before erasure'; END IF;
IF COALESCE(p.wallet_balance,0)<>0 THEN RAISE EXCEPTION 'Wallet balance must be zero before erasure'; END IF;
SELECT count(*) INTO active_orders FROM public.orders WHERE user_id=p_user_id AND status='waiting';
IF active_orders>0 THEN RAISE EXCEPTION 'Active orders must finish before erasure'; END IF;
SELECT count(*) INTO pending_payments FROM public.payment_requests WHERE user_id=p_user_id AND status IN('pending','created');
IF pending_payments>0 THEN RAISE EXCEPTION 'Pending top-ups must be resolved before erasure'; END IF;
UPDATE public.orders SET phone_number=NULL,sms_code=NULL,sms_text=NULL,updated_at=now() WHERE user_id=p_user_id;
UPDATE public.support_tickets SET subject='Support record',message='[Personal content erased]',public_reply=NULL,admin_notes=NULL,updated_at=now() WHERE user_id=p_user_id;
UPDATE public.profiles SET email='deleted+'||replace(p_user_id::text,'-','')||'@redacted.invalid',full_name='Deleted User',is_banned=true,updated_at=now() WHERE id=p_user_id;
IF p_request_id IS NOT NULL THEN UPDATE public.data_deletion_requests SET status='completed',processed_by=p_actor_id,processed_at=now(),updated_at=now() WHERE id=p_request_id AND user_id=p_user_id; END IF;
RETURN jsonb_build_object('user_id',p_user_id,'financial_records_retained',true,'personal_data_erased',true); END; $$;


ALTER FUNCTION "public"."erase_user_personal_data"("p_user_id" "uuid", "p_actor_id" "uuid", "p_request_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."financial_integrity_report"() RETURNS "jsonb"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
WITH baseline AS (
  SELECT cutover_at FROM financial_ledger_baselines WHERE singleton = true
),
orders_without_debit AS (
  SELECT count(*) AS n FROM orders o CROSS JOIN baseline b
  WHERE o.created_at >= b.cutover_at
    AND NOT EXISTS (SELECT 1 FROM wallet_transactions w WHERE w.type='deduction' AND w.reference_type='order' AND w.reference_id=o.id::text AND w.status='completed')
),
order_debit_mismatch AS (
  SELECT count(*) AS n FROM orders o CROSS JOIN baseline b
  JOIN wallet_transactions w ON w.type='deduction' AND w.reference_type='order' AND w.reference_id=o.id::text AND w.status='completed'
  WHERE o.created_at >= b.cutover_at AND abs(coalesce(w.amount,0)-coalesce(o.sell_price_inr,o.price_inr,0)) > 0.01
),
refund_without_credit AS (
  SELECT count(*) AS n FROM orders o CROSS JOIN baseline b
  WHERE o.created_at >= b.cutover_at AND o.refund_status='refunded'
    AND NOT EXISTS (SELECT 1 FROM wallet_transactions w WHERE w.type='refund' AND w.reference_type='order' AND w.reference_id=o.id::text AND w.status='completed')
),
refund_amount_mismatch AS (
  SELECT count(*) AS n FROM orders o CROSS JOIN baseline b
  JOIN wallet_transactions w ON w.type='refund' AND w.reference_type='order' AND w.reference_id=o.id::text AND w.status='completed'
  WHERE o.created_at >= b.cutover_at AND abs(coalesce(w.amount,0)-coalesce(o.sell_price_inr,o.price_inr,0)) > 0.01
),
topup_without_credit AS (
  SELECT count(*) AS n FROM payment_requests p CROSS JOIN baseline b
  WHERE p.created_at >= b.cutover_at AND p.status IN('approved','paid')
    AND NOT EXISTS (SELECT 1 FROM wallet_transactions w WHERE w.type='topup' AND w.reference_type='payment_request' AND w.reference_id=p.id::text AND w.status='completed')
),
topup_amount_mismatch AS (
  SELECT count(*) AS n FROM payment_requests p CROSS JOIN baseline b
  JOIN wallet_transactions w ON w.type='topup' AND w.reference_type='payment_request' AND w.reference_id=p.id::text AND w.status='completed'
  WHERE p.created_at >= b.cutover_at AND p.status IN('approved','paid') AND abs(coalesce(w.amount,0)-coalesce(p.amount,0)) > 0.01
),
wallet_balance_mismatch AS (
  SELECT count(*) AS n FROM profiles p CROSS JOIN baseline b
  LEFT JOIN LATERAL (
    SELECT balance_after, created_at
    FROM wallet_transactions w
    WHERE w.user_id=p.id AND w.status='completed'
    ORDER BY w.created_at DESC,w.id DESC
    LIMIT 1
  ) latest ON true
  WHERE latest.created_at >= b.cutover_at
    AND latest.balance_after IS NOT NULL
    AND abs(coalesce(p.wallet_balance,0)-latest.balance_after)>0.01
),
legacy_unlinked_orders AS (
  SELECT count(*) AS n FROM orders o CROSS JOIN baseline b
  WHERE o.created_at < b.cutover_at
    AND NOT EXISTS (SELECT 1 FROM wallet_transactions w WHERE w.type='deduction' AND w.reference_type='order' AND w.reference_id=o.id::text AND w.status='completed')
),
legacy_unlinked_topups AS (
  SELECT count(*) AS n FROM payment_requests p CROSS JOIN baseline b
  WHERE p.created_at < b.cutover_at AND p.status IN('approved','paid')
    AND NOT EXISTS (SELECT 1 FROM wallet_transactions w WHERE w.type='topup' AND w.reference_type='payment_request' AND w.reference_id=p.id::text AND w.status='completed')
),
totals AS (
  SELECT (SELECT cutover_at FROM baseline) cutover_at,
         (SELECT n FROM orders_without_debit) orders_without_debit,
         (SELECT n FROM order_debit_mismatch) order_debit_mismatch,
         (SELECT n FROM refund_without_credit) refunds_without_credit,
         (SELECT n FROM refund_amount_mismatch) refund_amount_mismatch,
         (SELECT n FROM topup_without_credit) topups_without_credit,
         (SELECT n FROM topup_amount_mismatch) topup_amount_mismatch,
         (SELECT n FROM wallet_balance_mismatch) wallet_balance_mismatch,
         (SELECT n FROM legacy_unlinked_orders) legacy_unlinked_orders,
         (SELECT n FROM legacy_unlinked_topups) legacy_unlinked_topups
)
SELECT jsonb_build_object(
  'checkedAt',now(), 'baselineAt',cutover_at,
  'ordersWithoutDebit',orders_without_debit, 'orderDebitMismatch',order_debit_mismatch,
  'refundsWithoutCredit',refunds_without_credit, 'refundAmountMismatch',refund_amount_mismatch,
  'topupsWithoutCredit',topups_without_credit, 'topupAmountMismatch',topup_amount_mismatch,
  'walletBalanceMismatch',wallet_balance_mismatch,
  'legacyUnlinkedOrders',legacy_unlinked_orders, 'legacyUnlinkedTopups',legacy_unlinked_topups,
  'totalIssues',orders_without_debit+order_debit_mismatch+refunds_without_credit+refund_amount_mismatch+topups_without_credit+topup_amount_mismatch+wallet_balance_mismatch
) FROM totals;
$$;


ALTER FUNCTION "public"."financial_integrity_report"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_new_user"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog', 'public', 'auth', 'extensions'
    AS $$
DECLARE
    v_code TEXT;
BEGIN
    v_code := upper(substring(replace(gen_random_uuid()::text, '-', ''), 1, 8));
    INSERT INTO public.profiles (id, email, full_name, referral_code)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', ''),
        v_code
    )
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."handle_new_user"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."increment_total_orders"("p_user_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog', 'public', 'auth', 'extensions'
    AS $$
BEGIN
    UPDATE public.profiles
    SET total_orders = COALESCE(total_orders, 0) + 1,
        updated_at = NOW()
    WHERE id = p_user_id;
END;
$$;


ALTER FUNCTION "public"."increment_total_orders"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."post_wallet_transaction"("p_user_id" "uuid", "p_amount" numeric, "p_type" "text", "p_description" "text", "p_reference_type" "text" DEFAULT NULL::"text", "p_reference_id" "text" DEFAULT NULL::"text", "p_idempotency_key" "text" DEFAULT NULL::"text") RETURNS TABLE("transaction_id" "uuid", "balance_after" numeric)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_balance DECIMAL(12,4);
  v_tx public.wallet_transactions%ROWTYPE;
BEGIN
  IF p_amount = 0 OR p_type NOT IN ('topup','deduction','refund','admin_credit','admin_grant','referral_bonus') THEN
    RAISE EXCEPTION 'invalid_wallet_transaction';
  END IF;
  IF p_type = 'deduction' AND p_amount >= 0 THEN
    RAISE EXCEPTION 'wallet_deduction_must_be_negative';
  END IF;
  IF p_type <> 'deduction' AND p_amount <= 0 THEN
    RAISE EXCEPTION 'wallet_credit_must_be_positive';
  END IF;

  -- The append-only trigger only permits this RPC's transaction-local marker.
  PERFORM set_config('app.wallet_posting', 'trusted', true);

  IF p_idempotency_key IS NOT NULL THEN
    SELECT * INTO v_tx FROM public.wallet_transactions WHERE idempotency_key = p_idempotency_key;
    IF FOUND THEN
      RETURN QUERY SELECT v_tx.id, v_tx.balance_after;
      RETURN;
    END IF;
  END IF;

  SELECT wallet_balance INTO v_balance FROM public.profiles WHERE id = p_user_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'profile_not_found'; END IF;
  IF v_balance + p_amount < 0 THEN RAISE EXCEPTION 'insufficient_wallet_balance'; END IF;

  v_balance := round(v_balance + p_amount, 4);
  UPDATE public.profiles SET wallet_balance = v_balance, updated_at = now() WHERE id = p_user_id;

  INSERT INTO public.wallet_transactions
    (user_id,type,amount,balance_after,description,status,reference_type,reference_id,idempotency_key)
  VALUES
    (p_user_id,p_type,abs(p_amount),v_balance,p_description,'completed',p_reference_type,p_reference_id,p_idempotency_key)
  RETURNING * INTO v_tx;

  RETURN QUERY SELECT v_tx.id, v_balance;
END;
$$;


ALTER FUNCTION "public"."post_wallet_transaction"("p_user_id" "uuid", "p_amount" numeric, "p_type" "text", "p_description" "text", "p_reference_type" "text", "p_reference_id" "text", "p_idempotency_key" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."purge_user_account"("p_user_id" "uuid", "p_actor_id" "uuid", "p_mode" "text" DEFAULT 'history'::"text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  target public.profiles%ROWTYPE;
  actor_role TEXT;
  order_count INTEGER;
  transaction_count INTEGER;
  payment_count INTEGER;
  order_sales DECIMAL(12,4);
  deposit_total DECIMAL(12,4);
  history_id UUID;
BEGIN
  IF p_mode NOT IN ('complete', 'history') THEN
    RAISE EXCEPTION 'Purge mode must be complete or history';
  END IF;

  SELECT role INTO actor_role FROM public.profiles WHERE id = p_actor_id;
  IF actor_role <> 'superadmin' THEN
    RAISE EXCEPTION 'Only a superadmin can purge user accounts';
  END IF;

  SELECT * INTO target FROM public.profiles WHERE id = p_user_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'User not found'; END IF;
  IF target.id = p_actor_id THEN RAISE EXCEPTION 'You cannot purge your own account'; END IF;
  IF target.role = 'superadmin' THEN RAISE EXCEPTION 'Super Admin accounts cannot be purged'; END IF;
  IF NOT COALESCE(target.is_banned, false) THEN RAISE EXCEPTION 'User must be suspended before purge'; END IF;

  SELECT count(*), COALESCE(sum(sell_price_inr), 0)
    INTO order_count, order_sales
    FROM public.orders WHERE user_id = p_user_id;
  SELECT count(*), COALESCE(sum(amount) FILTER (WHERE type = 'topup'), 0)
    INTO transaction_count, deposit_total
    FROM public.wallet_transactions WHERE user_id = p_user_id;
  SELECT count(*) INTO payment_count FROM public.payment_requests WHERE user_id = p_user_id;

  IF p_mode = 'history' THEN
    INSERT INTO public.user_purge_history (
      original_user_id, user_reference, user_email_hash, purge_mode,
      orders_count, wallet_transactions_count, payment_requests_count,
      total_order_sales, total_deposits, purged_by
    ) VALUES (
      p_user_id,
      'purged:' || replace(p_user_id::text, '-', ''),
      md5(lower(trim(target.email))),
      p_mode,
      order_count, transaction_count, payment_count,
      order_sales, deposit_total, p_actor_id
    ) RETURNING id INTO history_id;
  END IF;

  DELETE FROM public.data_deletion_requests WHERE user_id = p_user_id;
  DELETE FROM public.referral_fraud_logs WHERE referrer_id = p_user_id OR referee_id = p_user_id;
  IF p_mode = 'complete' THEN
    DELETE FROM public.admin_audit_logs WHERE target_type = 'user' AND target_id = p_user_id::text;
  END IF;
  DELETE FROM public.profiles WHERE id = p_user_id;
  DELETE FROM auth.users WHERE id = p_user_id;

  RETURN jsonb_build_object(
    'history_id', history_id,
    'user_id', p_user_id,
    'mode', p_mode,
    'orders_deleted', order_count,
    'wallet_transactions_deleted', transaction_count,
    'payment_requests_deleted', payment_count
  );
END;
$$;


ALTER FUNCTION "public"."purge_user_account"("p_user_id" "uuid", "p_actor_id" "uuid", "p_mode" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."refund_order_atomic"("p_order_id" "uuid", "p_terminal_status" "text", "p_reason" "text") RETURNS TABLE("transaction_id" "uuid", "balance_after" numeric)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_order public.orders%ROWTYPE;
  v_result RECORD;
BEGIN
  IF p_terminal_status NOT IN ('cancelled','expired') THEN RAISE EXCEPTION 'invalid_terminal_status'; END IF;
  SELECT * INTO v_order FROM public.orders WHERE id = p_order_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'order_not_found'; END IF;
  IF v_order.sms_code IS NOT NULL OR v_order.status IN ('code_received','completed') THEN
    RAISE EXCEPTION 'otp_delivered_not_refundable';
  END IF;

  SELECT * INTO v_result FROM public.post_wallet_transaction(
    v_order.user_id, v_order.sell_price_inr, 'refund', p_reason,
    'order', v_order.id::text, concat('refund:', v_order.id::text)
  );

  UPDATE public.orders SET
    status = p_terminal_status,
    refund_status = 'refunded',
    refund_transaction_id = v_result.transaction_id,
    refunded_at = coalesce(refunded_at, now()),
    cancelled_at = CASE WHEN p_terminal_status = 'cancelled' THEN coalesce(cancelled_at, now()) ELSE cancelled_at END,
    expired_at = CASE WHEN p_terminal_status = 'expired' THEN coalesce(expired_at, now()) ELSE expired_at END,
    updated_at = now()
  WHERE id = p_order_id;

  RETURN QUERY SELECT v_result.transaction_id, v_result.balance_after;
END;
$$;


ALTER FUNCTION "public"."refund_order_atomic"("p_order_id" "uuid", "p_terminal_status" "text", "p_reason" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    SET "search_path" TO 'pg_catalog', 'public', 'auth', 'extensions'
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."set_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."user_order_metrics"("p_user_id" "uuid") RETURNS "jsonb"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT jsonb_build_object(
    'totalOrders', count(*),
    'activeOrders', count(*) FILTER (WHERE status = 'waiting'),
    'otpDelivered', count(*) FILTER (WHERE sms_code IS NOT NULL OR status IN ('code_received','completed')),
    'otpNotReceived', count(*) FILTER (WHERE sms_code IS NULL AND status IN ('cancelled','expired','refunded')),
    'totalRefunded', coalesce(sum(sell_price_inr) FILTER (WHERE refund_status = 'refunded'),0),
    'spentOnDelivered', coalesce(sum(sell_price_inr) FILTER (WHERE sms_code IS NOT NULL OR status IN ('code_received','completed')),0)
  ) FROM orders WHERE user_id = p_user_id;
$$;


ALTER FUNCTION "public"."user_order_metrics"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."user_order_metrics"("p_user_id" "uuid", "p_created_after" timestamp with time zone) RETURNS "jsonb"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT jsonb_build_object(
    'totalOrders', count(*),
    'activeOrders', count(*) FILTER (WHERE status = 'waiting'),
    'otpDelivered', count(*) FILTER (WHERE sms_code IS NOT NULL OR status IN ('code_received','completed')),
    'otpNotReceived', count(*) FILTER (WHERE sms_code IS NULL AND status IN ('cancelled','expired','refunded')),
    'totalRefunded', coalesce(sum(sell_price_inr) FILTER (WHERE refund_status = 'refunded'),0),
    'spentOnDelivered', coalesce(sum(sell_price_inr) FILTER (WHERE sms_code IS NOT NULL OR status IN ('code_received','completed')),0)
  ) FROM public.orders
  WHERE user_id = p_user_id AND (p_created_after IS NULL OR created_at >= p_created_after);
$$;


ALTER FUNCTION "public"."user_order_metrics"("p_user_id" "uuid", "p_created_after" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."wallet_funding_summary"() RETURNS "jsonb"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT jsonb_build_object(
    'totalTopups', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type = 'topup' AND status = 'completed'),
    'topupsToday', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type = 'topup' AND status = 'completed' AND (created_at AT TIME ZONE 'Asia/Kolkata')::date = (now() AT TIME ZONE 'Asia/Kolkata')::date),
    'topupCount', (SELECT count(*) FROM wallet_transactions WHERE type = 'topup' AND status = 'completed'),
    'manualFunding', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type = 'admin_credit' AND status = 'completed'),
    'manualFundingToday', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type = 'admin_credit' AND status = 'completed' AND (created_at AT TIME ZONE 'Asia/Kolkata')::date = (now() AT TIME ZONE 'Asia/Kolkata')::date),
    'manualFundingCount', (SELECT count(*) FROM wallet_transactions WHERE type = 'admin_credit' AND status = 'completed'),
    'freeFunds', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type = 'admin_grant' AND status = 'completed'),
    'freeFundsToday', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type = 'admin_grant' AND status = 'completed' AND (created_at AT TIME ZONE 'Asia/Kolkata')::date = (now() AT TIME ZONE 'Asia/Kolkata')::date),
    'freeFundsCount', (SELECT count(*) FROM wallet_transactions WHERE type = 'admin_grant' AND status = 'completed'),
    'cashCollected', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type IN ('topup','admin_credit') AND status = 'completed'),
    'cashCollectedToday', (SELECT coalesce(sum(amount),0) FROM wallet_transactions WHERE type IN ('topup','admin_credit') AND status = 'completed' AND (created_at AT TIME ZONE 'Asia/Kolkata')::date = (now() AT TIME ZONE 'Asia/Kolkata')::date),
    'walletLiability', (SELECT coalesce(sum(wallet_balance),0) FROM profiles WHERE role = 'user')
  );
$$;


ALTER FUNCTION "public"."wallet_funding_summary"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."admin_audit_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "actor_id" "uuid",
    "action" "text" NOT NULL,
    "target_type" "text" NOT NULL,
    "target_id" "text",
    "metadata" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "ip_address" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "admin_audit_logs_action_check" CHECK ((("length"("action") >= 3) AND ("length"("action") <= 100))),
    CONSTRAINT "admin_audit_logs_target_type_check" CHECK ((("length"("target_type") >= 2) AND ("length"("target_type") <= 50)))
);


ALTER TABLE "public"."admin_audit_logs" OWNER TO "postgres";


COMMENT ON TABLE "public"."admin_audit_logs" IS 'Append-only server-side record of privileged administrative actions.';



CREATE TABLE IF NOT EXISTS "public"."admin_user_history_clears" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "cleared_at" timestamp with time zone NOT NULL,
    "mode" "text" NOT NULL,
    "actor_id" "uuid",
    "wallet_balance_before" numeric(12,4) DEFAULT 0 NOT NULL,
    "wallet_balance_after" numeric(12,4) DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "admin_user_history_clears_mode_check" CHECK (("mode" = ANY (ARRAY['all'::"text", 'preserve_funding'::"text"])))
);


ALTER TABLE "public"."admin_user_history_clears" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."data_deletion_requests" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "user_message" "text",
    "admin_notes" "text",
    "processed_by" "uuid",
    "requested_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "processed_at" timestamp with time zone,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "data_deletion_requests_admin_notes_check" CHECK ((("admin_notes" IS NULL) OR ("length"("admin_notes") <= 2000))),
    CONSTRAINT "data_deletion_requests_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'approved'::"text", 'rejected'::"text", 'completed'::"text"]))),
    CONSTRAINT "data_deletion_requests_user_message_check" CHECK ((("user_message" IS NULL) OR ("length"("user_message") <= 1000)))
);


ALTER TABLE "public"."data_deletion_requests" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."financial_ledger_baselines" (
    "singleton" boolean DEFAULT true NOT NULL,
    "cutover_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "financial_ledger_baselines_singleton_check" CHECK ("singleton")
);


ALTER TABLE "public"."financial_ledger_baselines" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."operational_alerts" (
    "alert_key" "text" NOT NULL,
    "alert_type" "text" NOT NULL,
    "channel" "text" NOT NULL,
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "details" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "last_error" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "operational_alerts_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'sent'::"text", 'failed'::"text"])))
);


ALTER TABLE "public"."operational_alerts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."order_events" (
    "id" bigint NOT NULL,
    "order_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "event_type" "text" NOT NULL,
    "from_status" "text",
    "to_status" "text",
    "refund_status" "text",
    "details" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "order_events_event_type_check" CHECK (("event_type" = ANY (ARRAY['created'::"text", 'status_changed'::"text", 'otp_received'::"text", 'refunded'::"text", 'snapshot'::"text"])))
);


ALTER TABLE "public"."order_events" OWNER TO "postgres";


ALTER TABLE "public"."order_events" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."order_events_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."orders" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "activation_id" "text" NOT NULL,
    "service_code" "text" NOT NULL,
    "service_name" "text" NOT NULL,
    "country_code" integer NOT NULL,
    "country_name" "text" NOT NULL,
    "phone_number" "text" NOT NULL,
    "cost_price_usd" numeric(12,4) NOT NULL,
    "sell_price_inr" numeric(12,4) NOT NULL,
    "sms_code" "text",
    "sms_text" "text",
    "status" "text" DEFAULT 'waiting'::"text" NOT NULL,
    "tiger_status" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "price_inr" numeric(12,4),
    "expires_at" timestamp with time zone,
    "fx_rate" numeric(12,6),
    "cost_price_inr" numeric(12,4),
    "cancelled_at" timestamp with time zone,
    "expired_at" timestamp with time zone,
    "refund_status" "text" DEFAULT 'not_applicable'::"text" NOT NULL,
    "refund_due_at" timestamp with time zone,
    "refunded_at" timestamp with time zone,
    "refund_transaction_id" "uuid",
    "refund_failure_reason" "text",
    CONSTRAINT "orders_refund_status_check" CHECK (("refund_status" = ANY (ARRAY['not_applicable'::"text", 'pending'::"text", 'processing'::"text", 'refunded'::"text", 'failed'::"text"]))),
    CONSTRAINT "orders_status_check" CHECK (("status" = ANY (ARRAY['waiting'::"text", 'code_received'::"text", 'completed'::"text", 'cancelled'::"text", 'refunded'::"text", 'expired'::"text"])))
);


ALTER TABLE "public"."orders" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."payment_requests" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "amount" numeric(12,4) NOT NULL,
    "payment_method" "text" NOT NULL,
    "gateway_order_id" "text",
    "transaction_id" "text",
    "status" "text" DEFAULT 'pending'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "screenshot_url" "text",
    "admin_notes" "text",
    CONSTRAINT "payment_requests_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'approved'::"text", 'rejected'::"text", 'created'::"text", 'paid'::"text", 'failed'::"text", 'expired'::"text"])))
);


ALTER TABLE "public"."payment_requests" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."pricing_rules" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "service_code" "text",
    "country_code" integer,
    "markup_type" "text" NOT NULL,
    "markup_value" numeric(12,4) NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "priority" integer DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "pricing_rules_markup_type_check" CHECK (("markup_type" = ANY (ARRAY['percentage'::"text", 'flat'::"text", 'fixed_price'::"text"])))
);


ALTER TABLE "public"."pricing_rules" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."profiles" (
    "id" "uuid" NOT NULL,
    "email" "text" NOT NULL,
    "full_name" "text",
    "role" "text" DEFAULT 'user'::"text" NOT NULL,
    "wallet_balance" numeric(12,4) DEFAULT 0.0000 NOT NULL,
    "total_spent" numeric(12,4) DEFAULT 0.0000 NOT NULL,
    "total_orders" integer DEFAULT 0 NOT NULL,
    "is_banned" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "referral_code" "text",
    "referred_by" "text",
    "signup_ip" "text",
    "signup_isp" "text",
    "signup_country" "text",
    "signup_city" "text",
    "last_login_ip" "text",
    "last_login_isp" "text",
    "last_login_country" "text",
    "last_login_city" "text",
    "last_login_at" timestamp with time zone,
    "currency_preference" "text",
    CONSTRAINT "profiles_currency_preference_check" CHECK ((("currency_preference" IS NULL) OR ("currency_preference" = ANY (ARRAY['INR'::"text", 'USD'::"text"])))),
    CONSTRAINT "profiles_role_check" CHECK (("role" = ANY (ARRAY['user'::"text", 'admin'::"text", 'superadmin'::"text"])))
);


ALTER TABLE "public"."profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."purchase_intents" (
    "request_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "service_code" "text" NOT NULL,
    "country_code" integer NOT NULL,
    "status" "text" DEFAULT 'processing'::"text" NOT NULL,
    "response" "jsonb",
    "error_code" "text",
    "error_message" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "purchase_intents_status_check" CHECK (("status" = ANY (ARRAY['processing'::"text", 'completed'::"text", 'failed'::"text"])))
);


ALTER TABLE "public"."purchase_intents" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."referral_fraud_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "referrer_id" "uuid",
    "referee_id" "uuid",
    "fraud_score" integer DEFAULT 0 NOT NULL,
    "reasons" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "action_taken" "text" DEFAULT 'blocked'::"text" NOT NULL,
    "ip_address" "text",
    "isp" "text",
    "user_agent" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."referral_fraud_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."referrals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "referrer_id" "uuid" NOT NULL,
    "referred_id" "uuid" NOT NULL,
    "referral_code" "text" NOT NULL,
    "deposit_count" integer DEFAULT 0 NOT NULL,
    "bonus_paid_1" boolean DEFAULT false NOT NULL,
    "bonus_paid_2" boolean DEFAULT false NOT NULL,
    "bonus_paid_3" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "fraud_status" "text" DEFAULT 'clean'::"text" NOT NULL,
    "fraud_score" integer DEFAULT 0 NOT NULL,
    "fraud_reasons" "jsonb" DEFAULT '[]'::"jsonb",
    "attribution_ip" "text",
    "attribution_isp" "text",
    "attribution_user_agent" "text"
);


ALTER TABLE "public"."referrals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."settings" (
    "key" "text" NOT NULL,
    "value" "jsonb" NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."support_tickets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "order_id" "uuid",
    "subject" "text" NOT NULL,
    "message" "text" NOT NULL,
    "status" "text" DEFAULT 'open'::"text" NOT NULL,
    "priority" "text" DEFAULT 'normal'::"text" NOT NULL,
    "admin_notes" "text",
    "assigned_to" "uuid",
    "resolved_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "public_reply" "text",
    "ticket_type" "text" DEFAULT 'general_help'::"text" NOT NULL,
    "attachment" "jsonb",
    CONSTRAINT "support_tickets_admin_notes_check" CHECK ((("admin_notes" IS NULL) OR ("length"("admin_notes") <= 4000))),
    CONSTRAINT "support_tickets_message_check" CHECK ((("length"("message") >= 10) AND ("length"("message") <= 2000))),
    CONSTRAINT "support_tickets_priority_check" CHECK (("priority" = ANY (ARRAY['low'::"text", 'normal'::"text", 'high'::"text", 'urgent'::"text"]))),
    CONSTRAINT "support_tickets_public_reply_check" CHECK ((("public_reply" IS NULL) OR ("length"("public_reply") <= 4000))),
    CONSTRAINT "support_tickets_status_check" CHECK (("status" = ANY (ARRAY['open'::"text", 'in_progress'::"text", 'resolved'::"text", 'closed'::"text"]))),
    CONSTRAINT "support_tickets_subject_check" CHECK ((("length"("subject") >= 5) AND ("length"("subject") <= 120))),
    CONSTRAINT "support_tickets_ticket_type_check" CHECK (("ticket_type" = ANY (ARRAY['general_help'::"text", 'payment_issue'::"text", 'order_issue'::"text", 'bug_report'::"text", 'account_security'::"text"])))
);


ALTER TABLE "public"."support_tickets" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_purge_history" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "original_user_id" "uuid" NOT NULL,
    "user_reference" "text" NOT NULL,
    "user_email_hash" "text" NOT NULL,
    "purge_mode" "text" NOT NULL,
    "orders_count" integer DEFAULT 0 NOT NULL,
    "wallet_transactions_count" integer DEFAULT 0 NOT NULL,
    "payment_requests_count" integer DEFAULT 0 NOT NULL,
    "total_order_sales" numeric(12,4) DEFAULT 0 NOT NULL,
    "total_deposits" numeric(12,4) DEFAULT 0 NOT NULL,
    "purged_by" "uuid",
    "purged_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "user_purge_history_purge_mode_check" CHECK (("purge_mode" = ANY (ARRAY['complete'::"text", 'history'::"text"])))
);


ALTER TABLE "public"."user_purge_history" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_security_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "event_type" "text" NOT NULL,
    "ip_address" "text" NOT NULL,
    "isp" "text",
    "asn" integer,
    "country" "text",
    "region" "text",
    "city" "text",
    "user_agent" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "user_security_logs_event_type_check" CHECK (("event_type" = ANY (ARRAY['signup'::"text", 'login'::"text", 'oauth_login'::"text", 'password_reset'::"text", 'session_refresh'::"text"])))
);


ALTER TABLE "public"."user_security_logs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."wallet_transactions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "type" "text" NOT NULL,
    "amount" numeric(12,4) NOT NULL,
    "balance_after" numeric(12,4) NOT NULL,
    "description" "text",
    "payment_id" "text",
    "payment_method" "text",
    "status" "text" DEFAULT 'completed'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "reference_type" "text",
    "reference_id" "text",
    "idempotency_key" "text",
    CONSTRAINT "wallet_transactions_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'completed'::"text", 'failed'::"text"]))),
    CONSTRAINT "wallet_transactions_type_check" CHECK (("type" = ANY (ARRAY['topup'::"text", 'deduction'::"text", 'refund'::"text", 'admin_credit'::"text", 'admin_grant'::"text", 'referral_bonus'::"text", 'opening_balance'::"text"])))
);


ALTER TABLE "public"."wallet_transactions" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."wallet_admin_funding" WITH ("security_invoker"='true') AS
 SELECT "id",
    "user_id",
    "type" AS "funding_type",
    "amount",
    "balance_after",
    "description",
    "status",
    "reference_type",
    "reference_id",
    "idempotency_key",
    "created_at"
   FROM "public"."wallet_transactions"
  WHERE ("type" = ANY (ARRAY['admin_credit'::"text", 'admin_grant'::"text"]));


ALTER VIEW "public"."wallet_admin_funding" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."wallet_deductions" WITH ("security_invoker"='true') AS
 SELECT "id",
    "user_id",
    "amount",
    "balance_after",
    "description",
    "status",
    "reference_type",
    "reference_id",
    "idempotency_key",
    "created_at"
   FROM "public"."wallet_transactions"
  WHERE ("type" = 'deduction'::"text");


ALTER VIEW "public"."wallet_deductions" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."wallet_referral_bonuses" WITH ("security_invoker"='true') AS
 SELECT "id",
    "user_id",
    "amount",
    "balance_after",
    "description",
    "status",
    "reference_type",
    "reference_id",
    "idempotency_key",
    "created_at"
   FROM "public"."wallet_transactions"
  WHERE ("type" = 'referral_bonus'::"text");


ALTER VIEW "public"."wallet_referral_bonuses" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."wallet_refunds" WITH ("security_invoker"='true') AS
 SELECT "id",
    "user_id",
    "amount",
    "balance_after",
    "description",
    "status",
    "reference_type",
    "reference_id",
    "idempotency_key",
    "created_at"
   FROM "public"."wallet_transactions"
  WHERE ("type" = 'refund'::"text");


ALTER VIEW "public"."wallet_refunds" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."wallet_topups" WITH ("security_invoker"='true') AS
 SELECT "id",
    "user_id",
    "amount",
    "balance_after",
    "description",
    "status",
    "reference_type",
    "reference_id",
    "idempotency_key",
    "created_at"
   FROM "public"."wallet_transactions"
  WHERE ("type" = 'topup'::"text");


ALTER VIEW "public"."wallet_topups" OWNER TO "postgres";


ALTER TABLE ONLY "public"."admin_audit_logs"
    ADD CONSTRAINT "admin_audit_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."admin_user_history_clears"
    ADD CONSTRAINT "admin_user_history_clears_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."data_deletion_requests"
    ADD CONSTRAINT "data_deletion_requests_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."financial_ledger_baselines"
    ADD CONSTRAINT "financial_ledger_baselines_pkey" PRIMARY KEY ("singleton");



ALTER TABLE ONLY "public"."operational_alerts"
    ADD CONSTRAINT "operational_alerts_pkey" PRIMARY KEY ("alert_key");



ALTER TABLE ONLY "public"."order_events"
    ADD CONSTRAINT "order_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."payment_requests"
    ADD CONSTRAINT "payment_requests_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."pricing_rules"
    ADD CONSTRAINT "pricing_rules_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_referral_code_key" UNIQUE ("referral_code");



ALTER TABLE ONLY "public"."purchase_intents"
    ADD CONSTRAINT "purchase_intents_pkey" PRIMARY KEY ("request_id");



ALTER TABLE ONLY "public"."referral_fraud_logs"
    ADD CONSTRAINT "referral_fraud_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_referred_id_key" UNIQUE ("referred_id");



ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("key");



ALTER TABLE ONLY "public"."support_tickets"
    ADD CONSTRAINT "support_tickets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_purge_history"
    ADD CONSTRAINT "user_purge_history_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_security_logs"
    ADD CONSTRAINT "user_security_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."wallet_transactions"
    ADD CONSTRAINT "wallet_transactions_pkey" PRIMARY KEY ("id");



CREATE INDEX "admin_audit_logs_actor_idx" ON "public"."admin_audit_logs" USING "btree" ("actor_id", "created_at" DESC);



CREATE INDEX "admin_audit_logs_created_at_idx" ON "public"."admin_audit_logs" USING "btree" ("created_at" DESC);



CREATE INDEX "admin_audit_logs_target_idx" ON "public"."admin_audit_logs" USING "btree" ("target_type", "target_id", "created_at" DESC);



CREATE INDEX "admin_user_history_clears_user_time_idx" ON "public"."admin_user_history_clears" USING "btree" ("user_id", "cleared_at" DESC);



CREATE UNIQUE INDEX "data_deletion_one_pending_idx" ON "public"."data_deletion_requests" USING "btree" ("user_id") WHERE ("status" = 'pending'::"text");



CREATE INDEX "data_deletion_queue_idx" ON "public"."data_deletion_requests" USING "btree" ("status", "requested_at");



CREATE INDEX "idx_orders_activation_id" ON "public"."orders" USING "btree" ("activation_id");



CREATE INDEX "idx_orders_created_at" ON "public"."orders" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_orders_status" ON "public"."orders" USING "btree" ("status");



CREATE INDEX "idx_orders_user_id" ON "public"."orders" USING "btree" ("user_id");



CREATE INDEX "idx_payment_req_status" ON "public"."payment_requests" USING "btree" ("status");



CREATE INDEX "idx_payment_requests_user_id" ON "public"."payment_requests" USING "btree" ("user_id");



CREATE INDEX "idx_pricing_rules_active" ON "public"."pricing_rules" USING "btree" ("is_active") WHERE ("is_active" = true);



CREATE INDEX "idx_profiles_email" ON "public"."profiles" USING "btree" ("email");



CREATE INDEX "idx_profiles_referral_code" ON "public"."profiles" USING "btree" ("referral_code");



CREATE INDEX "idx_referral_fraud_logs_created_at" ON "public"."referral_fraud_logs" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_referral_fraud_logs_referee" ON "public"."referral_fraud_logs" USING "btree" ("referee_id");



CREATE INDEX "idx_referral_fraud_logs_referrer" ON "public"."referral_fraud_logs" USING "btree" ("referrer_id");



CREATE INDEX "idx_referrals_code" ON "public"."referrals" USING "btree" ("referral_code");



CREATE INDEX "idx_referrals_fraud_status" ON "public"."referrals" USING "btree" ("fraud_status");



CREATE INDEX "idx_referrals_referred" ON "public"."referrals" USING "btree" ("referred_id");



CREATE INDEX "idx_referrals_referrer" ON "public"."referrals" USING "btree" ("referrer_id");



CREATE INDEX "idx_user_security_logs_ip_address" ON "public"."user_security_logs" USING "btree" ("ip_address");



CREATE INDEX "idx_user_security_logs_user_id_created_at" ON "public"."user_security_logs" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "idx_wallet_transactions_created_at" ON "public"."wallet_transactions" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_wallet_transactions_user_id" ON "public"."wallet_transactions" USING "btree" ("user_id");



CREATE INDEX "operational_alerts_type_created_idx" ON "public"."operational_alerts" USING "btree" ("alert_type", "created_at" DESC);



CREATE INDEX "order_events_order_created_idx" ON "public"."order_events" USING "btree" ("order_id", "created_at");



CREATE INDEX "order_events_user_created_idx" ON "public"."order_events" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "orders_waiting_expiry_idx" ON "public"."orders" USING "btree" ("expires_at") WHERE ("status" = 'waiting'::"text");



CREATE UNIQUE INDEX "payment_requests_transaction_id_uidx" ON "public"."payment_requests" USING "btree" ("lower"(TRIM(BOTH FROM "transaction_id"))) WHERE (("transaction_id" IS NOT NULL) AND (TRIM(BOTH FROM "transaction_id") <> ''::"text"));



CREATE INDEX "purchase_intents_user_created_idx" ON "public"."purchase_intents" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "support_tickets_queue_idx" ON "public"."support_tickets" USING "btree" ("status", "priority", "created_at");



CREATE INDEX "support_tickets_type_idx" ON "public"."support_tickets" USING "btree" ("ticket_type", "created_at" DESC);



CREATE INDEX "support_tickets_user_created_idx" ON "public"."support_tickets" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "user_purge_history_purged_at_idx" ON "public"."user_purge_history" USING "btree" ("purged_at" DESC);



CREATE INDEX "wallet_transactions_funding_idx" ON "public"."wallet_transactions" USING "btree" ("type", "created_at" DESC) WHERE ("type" = ANY (ARRAY['topup'::"text", 'admin_credit'::"text", 'admin_grant'::"text"]));



CREATE UNIQUE INDEX "wallet_transactions_idempotency_key_uidx" ON "public"."wallet_transactions" USING "btree" ("idempotency_key") WHERE ("idempotency_key" IS NOT NULL);



CREATE OR REPLACE TRIGGER "orders_capture_event" AFTER INSERT OR UPDATE OF "status", "refund_status", "sms_code" ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."capture_order_event"();



CREATE OR REPLACE TRIGGER "trg_orders_updated_at" BEFORE UPDATE ON "public"."orders" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



CREATE OR REPLACE TRIGGER "trg_payment_requests_updated" BEFORE UPDATE ON "public"."payment_requests" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



CREATE OR REPLACE TRIGGER "trg_pricing_rules_updated" BEFORE UPDATE ON "public"."pricing_rules" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



CREATE OR REPLACE TRIGGER "trg_profiles_updated_at" BEFORE UPDATE ON "public"."profiles" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



CREATE OR REPLACE TRIGGER "trg_referrals_updated" BEFORE UPDATE ON "public"."referrals" FOR EACH ROW EXECUTE FUNCTION "public"."set_updated_at"();



CREATE OR REPLACE TRIGGER "wallet_transactions_append_only" BEFORE INSERT OR DELETE OR UPDATE ON "public"."wallet_transactions" FOR EACH ROW EXECUTE FUNCTION "public"."enforce_wallet_ledger_append_only"();



ALTER TABLE ONLY "public"."admin_audit_logs"
    ADD CONSTRAINT "admin_audit_logs_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."admin_user_history_clears"
    ADD CONSTRAINT "admin_user_history_clears_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."admin_user_history_clears"
    ADD CONSTRAINT "admin_user_history_clears_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."data_deletion_requests"
    ADD CONSTRAINT "data_deletion_requests_processed_by_fkey" FOREIGN KEY ("processed_by") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."data_deletion_requests"
    ADD CONSTRAINT "data_deletion_requests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id");



ALTER TABLE ONLY "public"."order_events"
    ADD CONSTRAINT "order_events_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."order_events"
    ADD CONSTRAINT "order_events_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_refund_transaction_id_fkey" FOREIGN KEY ("refund_transaction_id") REFERENCES "public"."wallet_transactions"("id");



ALTER TABLE ONLY "public"."orders"
    ADD CONSTRAINT "orders_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id");



ALTER TABLE ONLY "public"."payment_requests"
    ADD CONSTRAINT "payment_requests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id");



ALTER TABLE ONLY "public"."profiles"
    ADD CONSTRAINT "profiles_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."purchase_intents"
    ADD CONSTRAINT "purchase_intents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."referral_fraud_logs"
    ADD CONSTRAINT "referral_fraud_logs_referee_id_fkey" FOREIGN KEY ("referee_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."referral_fraud_logs"
    ADD CONSTRAINT "referral_fraud_logs_referrer_id_fkey" FOREIGN KEY ("referrer_id") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_referred_id_fkey" FOREIGN KEY ("referred_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_referrer_id_fkey" FOREIGN KEY ("referrer_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."support_tickets"
    ADD CONSTRAINT "support_tickets_assigned_to_fkey" FOREIGN KEY ("assigned_to") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."support_tickets"
    ADD CONSTRAINT "support_tickets_order_id_fkey" FOREIGN KEY ("order_id") REFERENCES "public"."orders"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."support_tickets"
    ADD CONSTRAINT "support_tickets_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_purge_history"
    ADD CONSTRAINT "user_purge_history_purged_by_fkey" FOREIGN KEY ("purged_by") REFERENCES "public"."profiles"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."user_security_logs"
    ADD CONSTRAINT "user_security_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."wallet_transactions"
    ADD CONSTRAINT "wallet_transactions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."profiles"("id");



CREATE POLICY "Admins can view referral fraud logs" ON "public"."referral_fraud_logs" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = ( SELECT "auth"."uid"() AS "uid")) AND ("profiles"."role" = 'admin'::"text")))));



CREATE POLICY "Users and admins can view security logs" ON "public"."user_security_logs" FOR SELECT USING (((( SELECT "auth"."uid"() AS "uid") = "user_id") OR (EXISTS ( SELECT 1
   FROM "public"."profiles"
  WHERE (("profiles"."id" = ( SELECT "auth"."uid"() AS "uid")) AND ("profiles"."role" = ANY (ARRAY['admin'::"text", 'superadmin'::"text"])))))));



CREATE POLICY "Users can view own orders" ON "public"."orders" FOR SELECT USING ((( SELECT "auth"."uid"() AS "uid") = "user_id"));



CREATE POLICY "Users can view own payment requests" ON "public"."payment_requests" FOR SELECT USING ((( SELECT "auth"."uid"() AS "uid") = "user_id"));



CREATE POLICY "Users can view own profile" ON "public"."profiles" FOR SELECT USING ((( SELECT "auth"."uid"() AS "uid") = "id"));



CREATE POLICY "Users can view own referrals" ON "public"."referrals" FOR SELECT USING (((( SELECT "auth"."uid"() AS "uid") = "referrer_id") OR (( SELECT "auth"."uid"() AS "uid") = "referred_id")));



CREATE POLICY "Users can view own transactions" ON "public"."wallet_transactions" FOR SELECT USING ((( SELECT "auth"."uid"() AS "uid") = "user_id"));



ALTER TABLE "public"."admin_audit_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."admin_user_history_clears" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."data_deletion_requests" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."financial_ledger_baselines" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."operational_alerts" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."order_events" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."orders" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."payment_requests" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."pricing_rules" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."purchase_intents" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."referral_fraud_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."referrals" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."support_tickets" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_purge_history" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_security_logs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."wallet_transactions" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";


ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."orders";



GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";






















































































































































REVOKE ALL ON FUNCTION "public"."admin_dashboard_metrics"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."admin_dashboard_metrics"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."approve_payment_request_atomic"("p_request_id" "uuid", "p_admin_id" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."approve_payment_request_atomic"("p_request_id" "uuid", "p_admin_id" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."capture_order_event"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."capture_order_event"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."check_email_exists"("p_email" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."check_email_exists"("p_email" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."cleanup_operational_records"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."cleanup_operational_records"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."clear_user_history"("p_user_id" "uuid", "p_actor_id" "uuid", "p_mode" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."clear_user_history"("p_user_id" "uuid", "p_actor_id" "uuid", "p_mode" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."enforce_wallet_ledger_append_only"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."enforce_wallet_ledger_append_only"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."erase_user_personal_data"("p_user_id" "uuid", "p_actor_id" "uuid", "p_request_id" "uuid") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."erase_user_personal_data"("p_user_id" "uuid", "p_actor_id" "uuid", "p_request_id" "uuid") TO "service_role";



REVOKE ALL ON FUNCTION "public"."financial_integrity_report"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."financial_integrity_report"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."handle_new_user"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "service_role";
GRANT ALL ON FUNCTION "public"."handle_new_user"() TO "supabase_auth_admin";



REVOKE ALL ON FUNCTION "public"."increment_total_orders"("p_user_id" "uuid") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."increment_total_orders"("p_user_id" "uuid") TO "service_role";



REVOKE ALL ON FUNCTION "public"."post_wallet_transaction"("p_user_id" "uuid", "p_amount" numeric, "p_type" "text", "p_description" "text", "p_reference_type" "text", "p_reference_id" "text", "p_idempotency_key" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."post_wallet_transaction"("p_user_id" "uuid", "p_amount" numeric, "p_type" "text", "p_description" "text", "p_reference_type" "text", "p_reference_id" "text", "p_idempotency_key" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."purge_user_account"("p_user_id" "uuid", "p_actor_id" "uuid", "p_mode" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."purge_user_account"("p_user_id" "uuid", "p_actor_id" "uuid", "p_mode" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."refund_order_atomic"("p_order_id" "uuid", "p_terminal_status" "text", "p_reason" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."refund_order_atomic"("p_order_id" "uuid", "p_terminal_status" "text", "p_reason" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."set_updated_at"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."set_updated_at"() TO "service_role";
GRANT ALL ON FUNCTION "public"."set_updated_at"() TO "supabase_admin";



REVOKE ALL ON FUNCTION "public"."user_order_metrics"("p_user_id" "uuid") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."user_order_metrics"("p_user_id" "uuid") TO "service_role";



REVOKE ALL ON FUNCTION "public"."user_order_metrics"("p_user_id" "uuid", "p_created_after" timestamp with time zone) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."user_order_metrics"("p_user_id" "uuid", "p_created_after" timestamp with time zone) TO "service_role";



REVOKE ALL ON FUNCTION "public"."wallet_funding_summary"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."wallet_funding_summary"() TO "service_role";


















GRANT ALL ON TABLE "public"."admin_audit_logs" TO "service_role";



GRANT ALL ON TABLE "public"."admin_user_history_clears" TO "service_role";



GRANT ALL ON TABLE "public"."data_deletion_requests" TO "service_role";



GRANT ALL ON TABLE "public"."financial_ledger_baselines" TO "service_role";



GRANT ALL ON TABLE "public"."operational_alerts" TO "service_role";



GRANT ALL ON TABLE "public"."order_events" TO "service_role";



GRANT ALL ON SEQUENCE "public"."order_events_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."order_events_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."order_events_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."orders" TO "anon";
GRANT ALL ON TABLE "public"."orders" TO "authenticated";
GRANT ALL ON TABLE "public"."orders" TO "service_role";



GRANT ALL ON TABLE "public"."payment_requests" TO "anon";
GRANT ALL ON TABLE "public"."payment_requests" TO "authenticated";
GRANT ALL ON TABLE "public"."payment_requests" TO "service_role";



GRANT ALL ON TABLE "public"."pricing_rules" TO "anon";
GRANT ALL ON TABLE "public"."pricing_rules" TO "authenticated";
GRANT ALL ON TABLE "public"."pricing_rules" TO "service_role";



GRANT ALL ON TABLE "public"."profiles" TO "anon";
GRANT ALL ON TABLE "public"."profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."profiles" TO "service_role";



GRANT ALL ON TABLE "public"."purchase_intents" TO "service_role";



GRANT ALL ON TABLE "public"."referral_fraud_logs" TO "anon";
GRANT ALL ON TABLE "public"."referral_fraud_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."referral_fraud_logs" TO "service_role";



GRANT ALL ON TABLE "public"."referrals" TO "anon";
GRANT ALL ON TABLE "public"."referrals" TO "authenticated";
GRANT ALL ON TABLE "public"."referrals" TO "service_role";



GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";



GRANT ALL ON TABLE "public"."support_tickets" TO "service_role";



GRANT ALL ON TABLE "public"."user_purge_history" TO "service_role";



GRANT ALL ON TABLE "public"."user_security_logs" TO "anon";
GRANT ALL ON TABLE "public"."user_security_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."user_security_logs" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_transactions" TO "anon";
GRANT ALL ON TABLE "public"."wallet_transactions" TO "authenticated";
GRANT ALL ON TABLE "public"."wallet_transactions" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_admin_funding" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_deductions" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_referral_bonuses" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_refunds" TO "service_role";



GRANT ALL ON TABLE "public"."wallet_topups" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";































